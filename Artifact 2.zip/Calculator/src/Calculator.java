import java.util.Scanner;
public class Calculator {
   public static void main(String[] args) {
      double firstNumber;
      double secondNumber;
      double answer;
      char op;
      Scanner reader = new Scanner(System.in);
      System.out.print("Enter two numbers: ");
      firstNumber = reader.nextDouble();
      secondNumber = reader.nextDouble();
      System.out.print("Enter an operator (+, -, *, /): ");
      op = reader.next().charAt(0);
      switch(op) {
         //Addition 
      	case '+': answer = firstNumber + secondNumber;
            break;
         //Subtraction
         case '-': answer = firstNumber - secondNumber;
            break;
         //Multiplication
         case '*': answer = firstNumber * secondNumber;
         break;
         //Division
         case '/': answer = firstNumber / secondNumber;
         break;
         
      default: System.out.print("Error! Enter correct operator");
         return;
      }
      System.out.print("Answer:");
      System.out.print(firstNumber + " " + op + " " + secondNumber + " = " + answer);
   }
}